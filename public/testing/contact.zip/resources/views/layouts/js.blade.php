<script src="{{asset('plantilla/js/jquery.min.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery-migrate-3.0.1.min.js')}}"></script>
    <script src="{{asset('plantilla/js/popper.min.js')}}"></script>
    <script src="{{asset('plantilla/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.easing.1.3.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.waypoints.min.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.stellar.min.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.animateNumber.min.js')}}"></script>
    <script src="{{asset('plantilla/js/bootstrap-datepicker.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.timepicker.min.js')}}"></script>
    <script src="{{asset('plantilla/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('plantilla/js/jquery.magnific-popup.min.js')}}"></script>
    <script src="{{asset('plantilla/js/scrollax.min.js')}}"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="{{asset('plantilla/js/google-map.js')}}"></script>
    