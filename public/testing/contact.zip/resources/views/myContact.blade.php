@extends('layouts.myapp')

@section('content')

@endsection